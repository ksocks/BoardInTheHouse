---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

## Feature request for Cloudinary JS SDK
…(If your feature is for other SDKs, please request them there)

## Explain your use case
… (A high-level explanation of why you need this feature)

## Describe the problem you’re trying to solve
… (A more technical view of what you’d like to accomplish, and how this feature will help you achieve it)

## Do you have a proposed solution?
… (yes, no? Please elaborate if needed)
